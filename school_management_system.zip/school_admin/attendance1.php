
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Attendence</title>
  <link rel="stylesheet" href="attendence.css">
  <link rel="stylesheet" href="leave.css"> 

   

    <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
    rel="stylesheet"
    /> 
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />

<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/> 
  <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 

</head>
<body>


<?php
include 'connection.php';
// error_reporting(0);

$sql = " SELECT * FROM stdinfo ORDER BY UID ASC";
$result = mysqli_query($conn,$sql);

?>


<div class="sidenav">
        <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            <!-- <div class="close" id="close-btn">
              <span class="material-icons-sharp">close</span>
            </div> -->
          </div>
    
          <div class="sidebar">
            <a href="princi.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="studentinfo.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
    
            <a href="attendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
    
            <a href="notice.php" class="active">
              <span class="material-icons-sharp">event_note </span>
              <h3>Notice</h3>
            </a>
            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
      <!-- ------------------------------end of sidebar---------------------- -->

        <!-- ==========================main==================== -->
        <div class="main">
          <div class="stable">  
            <h2>Student <span class="danger">Attendance</span> </h2> 
            
          
            <table>
              <thead>
                        <tr>
                
                  <th>Roll No</th>
                  <th> Name</th>
                
          <th>Present</th>
          <th>Absent</th>

          <!-- <th>Absent</th> -->
                </tr> <thead>
                    <tbody>

                    <?php
              
              while($rows=$result->fetch_assoc())
              {
          ?>
          <tr> 
              
              <td><?php echo $rows['UID'];?></td>
              <td><?php echo $rows['FName'];?></td>
<td>
              <button name= "P" vaue="P" style="color:green; cursor: pointer;" type="submit">P</button></td>
              <td>
<button  name= "A" value="A" style="color:red; cursor: pointer;" type="submit">A</button></td></form></thead>

              <!-- <td><buttn name="P" value="P" style="color:green; cursor: pointer;"><span class="material-symbols-sharp">
check_circle
</span></buttn></td>

              <td><buttn name="A" value="A" style="color:red; cursor: pointer;"><span class="material-symbols-sharp">
cancel</span></buttn></td> -->
              </tr>
              <?php
          }
          ?> 

<?php

include 'connection.php';

// echo date('j');
$d=Date('j');
if(isset($_POST['P']))
{
    $id=$_POST['id'];
    $sql1="UPDATE `stdatt1` SET `$d`='P' WHERE `UID`=$id";
    if(!mysqli_query($conn,$sql1))
    {
        echo "error";
    }
}
elseif(isset($_POST['A']))
{
    $id=$_POST['id'];
    $sql2="UPDATE `stdatt1` SET `$d`='A' WHERE `UID`=$id";
    if(!mysqli_query($conn,$sql2))
    {
        echo "error";
    }
}
?>

                    </tbody>
                <tbody>
            
                    </table>
                    </div> 
</div>        
</body>
</html>
