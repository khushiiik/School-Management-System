<?php
$server = "localhost";
$username = "root";
$password = "";
$db = "school";

$conn = mysqli_connect($server, $username, $password, $db);
if($conn->connect_error)
{
 echo "connection failed";
}
?>