<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Form</title>
    <link rel="stylesheet" href="studentsform.css?v<?php echo time(); ?>">
    <link rel="stylesheet" href="leave.css?v<?php echo time(); ?>"> 


    <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
    rel="stylesheet"
    />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />

<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
  <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
</head>
<body>
<?php
include 'connection.php';
// error_reporting(0);

$sql = " SELECT * FROM tchrinfo ORDER BY num ASC";
$result = mysqli_query($conn,$sql);
?>

<div class="sidenav">
        <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            <!-- <div class="close" id="close-btn">
              <span class="material-icons-sharp">close</span>
            </div> -->
          </div>
    
          <div class="sidebar">
            <a href="princi.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="studentinfo.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
    
            <a href="attendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a> -->
    
            <a href="notice.php" class="active">
              <span class="material-icons-sharp">event_note </span>
              <h3>Notice</h3>
            </a>
            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
      <!-- ------------------------------end of sidebar---------------------- -->
<div class="main">

              <div style="overflow-x:auto;">
 
              <div class="stable">  
              <h1 style="margin-top: 20px;" >Student <span style="color: #097997;"> Form</span><a href="studentinfo.php" class="hstr" 
   >
   <span class="material-symbols-sharp">
description
</span>
            <h3 class="hstr">Form</h3>
          </a></h1>  
  <table style="width: 121%;">
    <thead>
              <tr>
      
        <th>Roll No</th>
        <th>First Name</th>
        <th>Last Name</th>
<th>Gender</th>
<th>Class</th>
<th>Address</th>
<th>Phone</th>
<th>E-mail</th>
<th>Date of Birth</th>
<th>Age</th>
<th>Caste</th>
<th>Father</th>
<th>Mother</th>
<th>Admission Date</th>
<th>Blood Group</th>

<th>Edit</th>
<th>Delete</th>

      
    </tr> <thead>
      <tbody>

      <?php
              
              while($rows=$result->fetch_assoc())
              {
          ?>
          <tr> 
              
              <td><?php echo $rows['UID'];?></td>
              <td><?php echo $rows['FName'];?></td>
              <td><?php echo $rows['LName'];?></td>
              <td><?php echo $rows['Gender'];?></td>
              <td><?php echo $rows['standard'];?></td>
              <td><?php echo $rows['Address'];?></td>
              <td><?php echo $rows['Phone'];?></td>
              <td><?php echo $rows['Email'];?></td>
              <td><?php echo $rows['DOB'];?></td>
              <td><?php echo $rows['Age'];?></td>
              <td><?php echo $rows['Caste'];?></td>
              <td><?php echo $rows['Father'];?></td>
              <td><?php echo $rows['Mother'];?></td>
              <td><?php echo $rows['Admission_date'];?></td>
              <td><?php echo $rows['BloodG'];?></td>


              <td><a href="edit_std.php?UID=<?php echo $rows['UID']; ?>&fnm=<?php echo $rows['FName'];?>&ln=<?php echo $rows['LName'];?>&gen=<?php echo $rows['Gender'];?>&std=<?php echo $rows['standard'];?>&adrs=<?php echo $rows['Address'];?>&dob=<?php echo $rows['DOB'];?>&age=<?php echo $rows['Age'];?> &ph=<?php echo $rows['Phone'];?>&em=<?php echo $rows['Email'];?>&caste=<?php echo $rows['Caste'];?> &fthr=<?php echo $rows['Father'];?>& mthr=<?php echo $rows['Mother'];?>& ad_dt=<?php echo $rows['Admission_date'];?>&blg=<?php echo $rows['BloodG'];?>" class="mr-25" data-toggle="tooltip" data-original-title="Edit"> <i class="material-symbols-sharp">app_registration</i></a></td>

<td> 
<a href="dataS.php?delete=<?php echo $rows['UID'];?>" data-toggle="tooltip" name="delete" data-original-title="Delete" onclick="return confirm('Do you really want to delete?');"> <i class="material-symbols-sharp" style="color:red">delete_forever</i> </a>
              </td>

              <!-- <td><span class="material-symbols-sharp" style="  cursor: pointer; color:#ffbb55" name="edit">app_registration</span></td>
<td><span class="material-symbols-sharp" style="  cursor: pointer; color:#ff5555" name="delete">delete_forever</span></td> -->
        <!-- <td><input type="submit" name="delete" value="delete">delete</td>    -->
</tr>
           <?php
               }
           ?> 
           
      </tbody>
      
            </table>
            <!-- </div>
            <a href="#">Show All</a>
          </div>  -->
          </div>

          <!-- ----------------------end of teachers----------------------------------- -->
    <!-- -------------------------------------------end of insights-------------------------------------------------------- -->

            
      
        
        <?php
        include 'connection.php';
        // if(isset($_POST['submit']))
        // {
        //     $uid=$_POST['UID'];
        //     if(!is_numeric($uid < 0)){
        //       $error_message = "Please enter an valid Gr no.";
        //       }
        //     $fnm=$_POST['FName'];
        //     $lnm=$_POST['LName'];
        //     $fthr=$_POST['Father'];
        //     $mthr=$_POST['Mother'];
        //     $nation=$_POST['Nationality'];
        //     $reli=$_POST['Religion'];
        //     $caste=$_POST['Caste'];
        //     $add=$_POST['Address'];
        //     $ph=$_POST['Phone'];
        //     if(!is_numeric($ph < 0)){
        //       $error_message = "Please enter a valid Phone no.";
        //       }
        //     $email=$_POST['Email'];
        //     $std=$_POST['standard'];
        //     $dob=$_POST['DOB'];
        //     $age=$_POST['Age'];
        //     if(!is_numeric($age < 0 || $age > 20)){
        //     $error_message = "Please enter an age between 0 and 20.";
        //     }
        //     $gndr=$_POST['Gender'];
        //     $ad_dt=$_POST['Admission_date'];
        //     $Bl_g=$_POST['BloodG'];
            

          
            // $sql = "INSERT INTO stdinfo(`UID`,`FName`,`LName`,`DOB`,`Age`,`Gender`,`Admission_date`,`BloodG`,`Father`,`Mother`,`Nationality`,`Religion`,`Caste`,`Address`,`Phone`,`Email`,`standard`) VALUES ($uid,'$fnm','$lnm','$dob',$age,'$gndr','$ad_dt','$Bl_g','$fthr','$mthr','$nation','$reli','$caste','$add',$ph,'$email','$std');";
            // $result = mysqli_query($conn,$sql);
 
        // }
        ?>

<?php
include 'connection.php';

              if(isset($_GET['delete']))
             
             {
              $sdlt=$_GET['delete'];
              $sqldlt = "DELETE FROM stdinfo WHERE UID='$sdlt'";
              
              $rdlt = mysqli_query($conn, $sqldlt);
            
            }
             ?>

        </body>
</html>