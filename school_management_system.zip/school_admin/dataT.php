<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Form</title>
    <link rel="stylesheet" href="tchrcss.css?v<?php echo time(); ?>">
    <link rel="stylesheet" href="leave.css?v<?php echo time(); ?>"> 


    <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
    rel="stylesheet"
    />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />

<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
  <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
</head>
<body>
<?php
include 'connection.php';
// error_reporting(0);

$sql = " SELECT * FROM tchrinfo ORDER BY num ASC";
$result = mysqli_query($conn,$sql);
?>

<div class="sidenav">
    <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->
 
  
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            <!-- <div class="close" id="close-btn">
              <span class="material-icons-sharp">close</span>
            </div> -->
          </div>
    
          <div class="sidebar">
            <a href="princi.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="studentinfo.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
    
            <a href="adviewatt.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
     -->
            <a href="notice.php" class="active">
              <span class="material-icons-sharp">event_note </span>
              <h3>Notice</h3>
            </a>
            <a href="leave_manage.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
      <!-- ------------------------------end of sidebar---------------------- -->

        <!-- ==========================main==================== -->
        
        <div class="main">

        <div class="stable">  
        <h1 style="margin-top: 20px;" >Teacher <span style="color: #097997;"> Form</span><a href="tchrinfo.php" class="hstr" 
   >
   <span class="material-symbols-sharp">
description
</span>
            <h3 class="hstr">Form</h3>
          </a></h1>  
          <div style="overflow-x:auto;">

  <table style="width: 121%; margin-left:0; box-shadow: none;">  

    <thead>
      <tr>
        <th>No</th>
        <th>Name</th>
        <th>Qualification</th>
                <th>Phone No</th>        
                <th>E-mail</th>
                <th>Gender</th>
                <th>Work Experience</th>  
                <th>DOB</th>
                <th>Joining Date</th>
        <th>Blood Group</th>
        <th>Caste</th>
        <th>Address</th>
           <th>Edit</th>
           <th>Delete</th>   
    </tr> </thead>
      <tbody>

      <?php
              
              while($rows=$result->fetch_assoc())
              {
          ?>
          <tr> 
                
              <td><?php echo $rows['num'];?></td>
              <td><?php echo $rows['Name'];?></td>
              <td><?php echo $rows['Qualification'];?></td>
              <td><?php echo $rows['Phone'];?></td>
               <td><?php echo $rows['Email'];?></td>
               <td><?php echo $rows['Gender'];?></td>
               <td><?php echo $rows['WorkEp'];?></td>
               <td><?php echo $rows['DOB'];?></td>
               <td><?php echo $rows['JoiningD'];?></td>
               <td><?php echo $rows['BloodG'];?></td>
               <td><?php echo $rows['Caste'];?></td>
               <td><?php echo $rows['Address'];?></td>

<form method="POST">
               <td><a href="edit_tchr.php? num=<?php echo $rows['num']; ?> & nm=<?php echo $rows['Name'];?> & qlf=<?php echo $rows['Qualification'];?> & ph=<?php echo $rows['Phone'];?> & em=<?php echo $rows['Email'];?> & gen=<?php echo $rows['Gender'];?> & workex=<?php echo $rows['WorkEp'];?> & dob=<?php echo $rows['DOB'];?> & jn_dt=<?php echo $rows['JoiningD'];?> & blg=<?php echo $rows['BloodG'];?> & caste=<?php echo $rows['Caste'];?> & adrs=<?php echo $rows['Address'];?>" class="mr-25" data-toggle="tooltip" data-original-title="Edit"> <i class="material-symbols-sharp">app_registration</i></a></td>

<td>
<a href="dataT.php?delete=<?php echo $rows['num'];?>" data-toggle="tooltip" name="delete" data-original-title="Delete" onclick="return confirm('Do you really want to delete?');"> <i class="material-symbols-sharp" style="color:red">delete_forever</i> </a>

              </td>

               <!-- <td><span class="material-symbols-sharp" style="  cursor: pointer; color:#ffbb55">app_registration</span></td>
<td><span class="material-symbols-sharp" style="  cursor: pointer; color:#ff5555">delete_forever</span></td> -->

           </tr>
              </form>

              <?php
include 'connection.php';

              if(isset($_GET['delete']))
             {
              $dlt=$_GET['delete'];
              $sqldlt = "DELETE FROM tchrinfo WHERE num='$dlt'";
              
              $rdlt = mysqli_query($conn, $sqldlt);
              // header("localtion");
              // header("Location: ".$_SERVER['PHP_SELF']);
              if($rdlt){
                echo"<script>window.location.href='dataT.php';</script>";
  
              }
              }
             ?>

              <?php
              }
           ?> 
      </tbody>
  </table>
  </div>
  </div> 
            </body>
            </html>
    
     




