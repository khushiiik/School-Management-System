
-- --------------------------------------------------------

--
-- Table structure for table `stdinfo`
--

DROP TABLE IF EXISTS `stdinfo`;
CREATE TABLE `stdinfo` (
  `UID` int(20) NOT NULL,
  `FName` varchar(20) NOT NULL,
  `LName` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `Age` int(2) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Admission_date` date NOT NULL,
  `BloodG` varchar(3) NOT NULL,
  `Father` varchar(50) NOT NULL,
  `Mother` varchar(50) NOT NULL,
  `Nationality` varchar(10) NOT NULL,
  `Religion` varchar(10) NOT NULL,
  `Caste` varchar(10) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Phone` varchar(10) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `standard` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stdinfo`
--

INSERT INTO `stdinfo` (`UID`, `FName`, `LName`, `DOB`, `Age`, `Gender`, `Admission_date`, `BloodG`, `Father`, `Mother`, `Nationality`, `Religion`, `Caste`, `Address`, `Phone`, `Email`, `standard`) VALUES
(1001, 'Yashvi', 'Rathod', '2023-02-01', 18, 'Female', '2023-02-06', 'B+', 'Himanshubhai', 'Bhavitaben', 'Indian', 'Hindu', 'Mistri', 'abc', '2147483647', 'ryashvih@gmail.com', '5'),
(1002, 'khushi', 'koria', '2023-02-24', 20, 'female', '2023-02-28', 'A+', 'rajeshbhai', 'mnaben', 'Indian', 'Hindu', 'Mistri', 'apnanagar', '2147483647', 'khuhi25@gmail.com', '4'),
(1003, 'Meet', 'Sarola', '2009-02-16', 10, 'Male', '2023-02-23', 'A+', 'Jignebhai', 'Shilaben', 'Indian', 'Hindu', 'OBC', 'gurukul, gandhidham', '9785642861', 'meetsarola@gmail.com', '4');
