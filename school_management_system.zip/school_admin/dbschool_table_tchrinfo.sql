
-- --------------------------------------------------------

--
-- Table structure for table `tchrinfo`
--

DROP TABLE IF EXISTS `tchrinfo`;
CREATE TABLE `tchrinfo` (
  `No` int(2) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  `Qualification` varchar(20) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `JoiningD` date NOT NULL,
  `WorkEp` int(2) NOT NULL,
  `BloodG` varchar(3) NOT NULL,
  `Nationality` varchar(20) NOT NULL,
  `Religion` varchar(20) NOT NULL,
  `Caste` varchar(20) NOT NULL,
  `Phone` varchar(10) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tchrinfo`
--

INSERT INTO `tchrinfo` (`No`, `Name`, `DOB`, `Qualification`, `Gender`, `JoiningD`, `WorkEp`, `BloodG`, `Nationality`, `Religion`, `Caste`, `Phone`, `Email`, `Address`) VALUES
(1, 'Navin Thhakar', '1995-06-08', 'B.Ed', 'Male', '2023-02-23', 2, 'B+', 'Indian', 'Hindu', 'General', '2147483647', 'navinthhakr@gmail.com', 'Krishnanagar'),
(2, 'Kavita Jain', '1996-02-05', 'B.Ed', 'Female', '2023-01-05', 3, 'B+', 'Indian', 'Hindu', 'SC', '8546729132', 'kavita53@gmail.com', '17 vadi, adipur');
