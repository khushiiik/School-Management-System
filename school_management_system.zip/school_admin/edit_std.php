<?php
session_start();
if(!isset($_SESSION['currentuser']))
{
  echo"<script>window.location.href='login.php';</script>";
}

?>

<?php
include('connection.php');

error_reporting(0);
$uid=$_GET['UID'];
$fnm=$_GET['fnm'];
$lnm=$_GET['ln'];
$gndr=$_GET['gen'];
$std=$_GET['std'];
$add=$_GET['adrs'];
$dob=$_GET['dob'];
$ph=$_GET['ph']; 
$em=$_GET['em'];
$cst=$_GET['caste'];
$fthr=$_GET['fthr'];
$mthr=$_GET['mthr'];
$ad_dt=$_GET['ad_dt'];
$blg=$_GET['blg'];
$age=$_GET['age'];
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="studentsform.css?v<?php echo time(); ?>">
    <link rel="stylesheet" href="leave.css?v<?php echo time(); ?>"> 

      <title>Student Form</title>

    <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
    rel="stylesheet"
    />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
  <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 





</head>
<body>


<?php
include 'connection.php';
// error_reporting(0);

$sql = " SELECT * FROM stdinfo ORDER BY standard ASC";
$result = mysqli_query($conn,$sql);

?>

<div class="sidenav">

          <div class="top">
            <div class="logo">
              <!-- <img src="....." alt="logo" /> -->
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            
          </div>

          <div class="sidebar">
            <a href="Princi.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
  
            <a href="studentinfo.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
  
            <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>

            <a href="attendance1.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
  
            <!-- <a href="#" class="active">
            <span class="material-icons-sharp">currency_rupee</span>
            <h3>Fees</h3>
            </a> -->

            <a href="notice.php" class="active">
              <span class="material-icons-sharp">event_note </span>
              <h3>Notice</h3>
            </a>
  
            <a href="login.php" class="active">
            <span class="material-icons-sharp">logout </span>
            <h3>Logout</h3>
            </a>
        </div>
</div>

        <!-- ==========================main==================== -->
        <div class="main">
        <h1  style="margin-top: 20px;" >Student <span style="color: #097997;"> Form</span><a href="sdata.php" class="hstr" 
   >
   <span class="material-symbols-sharp">
demography
</span>
            <h3 class="hstr">Data</h3>
          </a></h1>
               <form method="POST" action="edit_std.php"> 
                    <div class="row">
                  <div class="col-25">
                    <label for="grno">GR no.</label>
                    <input type="text" id="number" name="UID" value="<?php echo $uid ?>" pattern="[0-9]{4}" placeholder="0000" required>
            
            
                  </div>
                        <div class="col-25">
                            <label for="first-name">First Name</label>
                            <input type="text" id="first-name" name="FName" value= "<?php echo $fnm ?>" style="text-transform:capitalize" required>
                        </div>
                        <div class="col-25">
                            <label for="last-name">Last Name</label>
                            <input type="text" id="last-name" name="LName" value= "<?php echo $lnm ?>"  style="text-transform:capitalize" required>
                        </div>

                    </div>
                <div class="row">
                  <div class="col-25">
                    <label for="father-name">Father Name</label>
                    <input type="text" id="father-name" name="Father" value="<?php echo "$fthr"?>" style="text-transform:capitalize" required>
                        </div>
                        <div class="col-25">
                            <label for="mother-name">Mother Name</label>
                            <input type="text" id="mother-name" name="Mother" value="<?php echo "$mthr"?>"style="text-transform:capitalize" required>
                        </div>
                </div>
                
                <div class="row">
                  <div class="col-25">
                            <label for="birthdate">Birthdate</label>
                            <input type="date" id="birthdate" name="DOB" value= "<?php echo $dob ?>"  required>
                        </div>
                        <div class="col-25">
                            <label for="age">Age</label>
                            <input type="text" id="age" name="Age" pattern="[0-9]{2}" placeholder="00" required value=<?php echo $age; ?>>
                        </div>
                </div>
                    <div class="row">
                        <div class="col-25">
                            <label for="gender">Gender</label>
                            <select id="gender" name="Gender" value= "<?php echo $gndr ?>" required>
                            <option value="<?php echo $gndr; ?>" selected><?php echo $gndr; ?></option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-25">
                            
                            <label for="admission-date">Admission Date</label>
                    <input type="date" id="admission-date" name="Admission_date"  required value="<?php echo $ad_dt; ?>">
                        </div>
                  <div class="col-25">
                    <label for="bloodgrp">Blood Group</label>
                    <select id="bloodgrp" name="BloodG" value="<?php echo "$blg"?>" required>
                      <option value="<?php echo $blg; ?>" selected><?php echo $blg; ?></option>
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB</option>
                      </select>
                  </div>
                </div>
                
                <div class="row">
                 
                  <div class="col-25">
                            <label for="caste">Caste</label>
                            <select id="caste" name="Caste" value="<?php echo "$cst"?>" required>
                            <option value="<?php echo $cst; ?>" selected><?php echo $cst; ?></option>
                                <option value="General">General</option>
                                <option value="OBC">OBC</option>
                                <option value="SC">SC</option>
                                <option value="ST">ST</option>
                                
                            </select>
                        </div>
                </div>
                <div class="row">
                    <div class="col-25">
                      <label for="Phone">Phone no.</label>
              <input type="tel" id="Phone" name="Phone" value= "<?php echo $ph ?>"  placeholder="Enter your phone number" pattern="[0-9]{10}" required>
                      </div>
                      <div class="col-25">
                    <label for="standard">Class</label>
                    <select id="standard" name="standard" value="<?php echo "$std"?>" required>
                    <option value="<?php echo $std; ?>" selected><?php echo $std; ?></option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7">7</option>
                      <option value="8">8</option>
              
                    </select>
                  </div>
                  </div>
                  <div class="row">
                  <div class="col-25">
                    <label for="email">Email:</label>
                      <input type="email" id="email" name="Email" value= "<?php echo $em ?>" placeholder="Enter your email address" required>
                      
                  </div>
                  <div class="col-25 addrs" >
                    <label for="address">Address:</label>
                    <textarea  id="address" name="Address"  placeholder="Enter your address" required><?php echo $add; ?></textarea>
                  </div>
                  </div>
                  <div class="row">
                    <div class="col-50">
                      <input type="submit" value="update" name="update">

                    </div>
                  </div>
                </div>
              
              </form>

      <?php

              while($rows=$result->fetch_assoc())
              {
          ?>
          <!-- <tr> 
              
              <td><?php echo $rows['UID'];?></td>
              <td><?php echo $rows['FName'];?></td>
              <td><?php echo $rows['LName'];?></td>
              <td><?php echo $rows['Gender'];?></td>
              <td><?php echo $rows['standard'];?></td>
              <td><?php echo $rows['Address'];?></td>
              <td><?php echo $rows['DOB'];?></td>
              <td><?php echo $rows['Phone'];?></td>
              <td><?php echo $rows['Email'];?></td>
              <td><?php echo $rows['DOB'];?></td>
              <td><?php echo $rows['Age'];?></td>
              <td><?php echo $rows['Caste'];?></td>
              <td><?php echo $rows['Father'];?></td>
              <td><?php echo $rows['Mother'];?></td>
              <td><?php echo $rows['Admission_date'];?></td>
              <td><?php echo $rows['BloodG'];?></td> -->

              <!-- <td><button span class="material-symbols-sharp" style="  cursor: pointer; color:#ffbb55" name="edit">app_registration</span></td> -->
<!-- <td><button span class="material-symbols-sharp" style="  cursor: pointer; color:#ff5555" name="delete">delete_forever</span></td>
<td><a href="edit_std.php?UID=<?php echo $rows['UID']; ?>&fnm=<?php echo $rows['FName'];?>&ln=<?php echo $rows['LName'];?>&gen=<?php echo $rows['Gender'];?>&std=<?php echo $rows['standard'];?>&adrs=<?php echo $rows['Address'];?>&dob=<?php echo $rows['DOB'];?>&age=<?php echo $rows['Age'];?> &ph=<?php echo $rows['Phone'];?>&em=<?php echo $rows['Email'];?>&caste=<?php echo $rows['Caste'];?>&fthr=<?php echo $rows['Father'];?>& mthr=<?php echo $rows['Mother'];?>& ad_dt=<?php echo $rows['Admission_date'];?>&blg=<?php echo $rows['BloodG'];?>" class="mr-25" data-toggle="tooltip" data-original-title="Edit"> <i class="material-symbols-sharp">app_registration</i></a></td>

<td>
<a href="sdata.php?delete=<?php echo $rows['UID'];?>" data-toggle="tooltip" name="delete" data-original-title="Delete" onclick="return confirm('Do you really want to delete?');"> <i class="material-symbols-sharp" style="color:red">delete_forever</i></a>

              </td>
          </tr> -->
          <?php
              }
          ?> 
      <!-- </tbody>
            </table>
            <a href="#">Show All</a>
          </div>  -->

          <!-- ----------------------end of teachers----------------------------------- -->
    <!-- -------------------------------------------end of insights-------------------------------------------------------- -->

<?php

// // Get the DOB and admission date inputs from the form
// $dob = $_POST['DOB'];
// $admission_date = $_POST['Admission_date'];

// // Convert the inputs to date objects
// $dob_date = date_create($dob);
// $admission_date = date_create($admission_date);

// // Compare the dates and display an error message if the admission date is before the DOB
// if ($admission_date < $dob_date) {
//     echo "Error: Admission date cannot be before DOB.";
// } else {
//     // Admission date is valid, continue with your form submission process
// }

?>


        <?php
        
        include 'connection.php';
        error_reporting(0);

        if(isset($_POST['update']))
        {
            $uid=$_POST['UID'];
            // if(!is_numeric($uid < 0)){
            //   $error_message = "Please enter an valid Gr no.";
            //   }
            $fnm=$_POST['FName'];
            $lnm=$_POST['LName'];
            $fthr=$_POST['Father'];
            $mthr=$_POST['Mother'];
            // $nation=$_POST['Nationality'];
            // $reli=$_POST['Religion'];
            $caste=$_POST['Caste'];
            $add=$_POST['Address'];
            $ph=$_POST['Phone'];
            // if(!is_numeric($ph < 0)){
            //   $error_message = "Please enter a valid Phone no.";
            //   }
            $email=$_POST['Email'];
            $std=$_POST['standard'];
            $dob=$_POST['DOB'];
            $age=$_POST['Age'];
            // if(!is_numeric($age < 0 || $age > 20)){
            // $error_message = "Please enter an age between 0 and 20.";
            // }
            $gndr=$_POST['Gender'];
            $ad_dt=$_POST['Admission_date'];
            $Bl_g=$_POST['BloodG'];
            
            $sqlup="UPDATE `stdinfo`  SET  `FName`='$fnm', `LName`='$lnm', `Father`='$fthr', `Mother`='$mthr', `Caste`='$caste', `DOB`='$dob',`Standard`='$std', `Address`='$add',  `Phone`='$ph', `Email`='$email', `Age`=$age, `Gender`='$gndr', `Admission_date`='$ad_dt' , `BloodG`='$Bl_g' WHERE UID=$uid;";

            // $sql = "INSERT INTO stdinfo(`UID`,`FName`,`LName`,`DOB`,`Age`,`Gender`,`Admission_date`,`BloodG`,`Father`,`Mother,`Caste`,`Address`,`Phone`,`Email`,`standard`) VALUES ($uid,'$fnm','$lnm','$dob',$age,'$gndr','$ad_dt','$Bl_g','$fthr','$mthr','$caste','$add',$ph,'$email','$std');";
            $result = mysqli_query($conn,$sqlup);
            if($result)
            {
                echo "success";
            }
            else{
                echo "failed";
            }
        }
          ?>

<?php
include 'connection.php';

              if(isset($_GET['delete']))
            {
              $sdlt=$_GET['delete'];
              $sqldlt = "DELETE FROM `stdinfo` WHERE UID='$sdlt'";
              $rdlt = mysqli_query($conn, $sqldlt);
            }
            ?>   
        </body>
</html>