<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="newlogin.css?v<?php echo time(); ?>" />

    <title>Login</title>
</head>
<body>
    <div class="hero">

    <div class="login-box">
        <p>Log<span style=" margin-right: 80%;">in</span></p>
        <form method="POST" action="login.php">
        <div class="form-group">
                  <select required name="userType" class="form-control mb-3">
                          <option value="" style="display: none;">Select User Roles</option>
                          <option value="Administrator" style="color:black; ">Administrator</option>
                          <option value="ClassTeacher" style="color:black;">ClassTeacher</option>
                        </select>
                    </div>

          <div class="user-box">
            <input required="" name="username" type="text">
            <label>User Id</label>
          </div>
          <div class="user-box">
            <input required="" name="pswrd" type="password">
            <label>Password</label>
          </div>
        
            <input type="submit" value="Submit" name="submit">

        </form>
      </div>
    
</div>


<?php
// error_reporting(0);
session_start();
include 'connection.php';

if(isset($_POST['submit'])){

$userType = $_POST['userType'];
$nm=$_POST['username'];
$pswrd=$_POST['pswrd'];



if($userType == "Administrator"){

  $query = "SELECT * FROM logininfo WHERE username = '$nm' AND pswrd = '$pswrd'";
  $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);

if ($num> 0) {
  
  // header("Location: princi.php");
  $_SESSION['currentuser']=$nm;
  echo "<script>window.location.href='princi.php';</script>";
}

  else{

    echo "<div class='alert alert-danger' role='alert'>
    Invalid Username/Password!
    </div>";

  }
}
else if($userType == "ClassTeacher"){

  $query = "SELECT * FROM tlogin WHERE username = '$nm' AND pswrd = '$pswrd'";
  // $rs = $conn->query($query);
  // $num = $rs->num_rows;
  // $rows = $rs->fetch_assoc();

  $rs=mysqli_query($conn,$query);
  $num=mysqli_num_rows($rs);
  $rows=mysqli_fetch_assoc($rs);

  $temp=$rows['std'];



if ($num> 0) {
  $_SESSION['id']=$temp;
  // header("Location: tadmin.php");
  echo "<script type = \"text/javascript\">
    window.location = (\"teacher/tadmin.php\")
    </script>";

}

  else{

    echo "<div class='alert alert-danger' role='alert'>
    Invalid Username/Password!
    </div>";

  }
}
else{

    echo "<div class='alert alert-danger' role='alert'>
    Invalid Username/Password!
    </div>";

}
}

//     $sql = "SELECT * FROM logininfo WHERE username='$nm' AND pswrd='$pswrd'";
//     $result = mysqli_query($conn, $sql);
//     $num = mysqli_num_rows($result);

// if ($num> 0) {
//   header("Location: princi.php");
// }
// else {
//   echo "Invalid password";
// }
// }
?>
</body>
</html>
