<?php

echo "hello world";
//connectiong to database
$servername="localhost";
$username="root";
$password="";

$conn = mysqli_connect($servername,$username,$password);
echo"succsess";
?>
<?php
$servername="localhost";
$username="root";
$password="";
?>