
<html>
    <body>

<?php
 include 'connection.php';
 error_reporting(0);
include 'picker.html';
if(isset($_POST['done'])){
    @$m=$_POST['month'];
    @$y=$_POST['year'];
    @$c=$_POST['sd'];

    
    if($m=="January")
    {
      $mn=1;
    }
    elseif($m=="February")
    {
      $mn=2;
    }
    elseif($m=="March")
    {
      $mn=3;
    }
    elseif($m=="April")
    {
      $mn=4;
    }
    elseif($m=="May")
    {
      $mn=5;
    }
    elseif($m=="June")
    {
      $mn=6;
    }
    elseif($m=="July")
    {
      $mn=7;
    }
    elseif($m=="August")
    {
      $mn=8;
    }
    elseif($m=="Sepetmber")
    {
      $mn=9;
    }
    elseif($m=="October")
    {
      $mn=10;
    }
    elseif($m=="November")
    {
      $mn=11;
    }
    elseif($m=="December")
    {
      $mn=12;
    }
    
echo $mn;
echo $y;
echo $c;

    
   
    $q="SELECT * FROM `stdatt1` WHERE `Month`='$mn' AND `Year`='$y';";
    // $q= "SELECT * FROM `stdatt1` WHERE `Month`=$mn AND `Year`=$y AND `standard`=$c;";
    $result = mysqli_query($conn,$q);
    
    if($result){
        echo "<div>
    <form method='POST'>
    <div class='stable'> 
            
    <div style='overflow-x:auto;text-align:left;'>

        <table style='width: 120%; margin-left:0; box-shadow: none;'>
          <thead>
            <tbody>
            <th>UID</th>
                <th>Standard</th>
                <th>Name</th>
                <th>1</th>
                <th>2</th>
                <th>3</th>
                <th>4</th>
                <th>5</th>
                <th>6</th>
                <th>7</th>
                <th>8</th>
                <th>9</th>
                <th>10</th>
                <th>11</th>
                <th>12</th>
                <th>13</th>
                <th>14</th>
                <th>15</th>
                <th>16</th>
                <th>17</th>
                <th>18</th>
                <th>19</th>
                <th>20</th>
                <th>21</th>
                <th>22</th>
                <th>23</th>
                <th>24</th>
                <th>25</th>
                <th>26</th>
                <th>27</th>
                <th>28</th>
                <th>29</th>
                <th>30</th>
                <th>31</th>"; }
    }

?>

    <?php   

  while($rows=$result->fetch_assoc())

  // $res=mysqli_query($conn, "SELECT COUNT(`1`) FROM `stdatt1`");
  // $data=mysqli_fetch_assoc($res);
  // echo $data['Total'];
    {
     
    ?>
    <tr>
       
    <td><?php echo $rows['UID'];?></td>
  <td><?php echo $rows['standard'];?></td>
  <td><?php echo $rows['FName'];?></td>
  <td><?php echo $rows['1'];?></td>
  <td><?php echo $rows['2'];?></td>
  <td><?php echo $rows['3'];?></td>
  <td><?php echo $rows['4'];?></td>
  <td><?php echo $rows['5'];?></td>
  <td><?php echo $rows['6'];?></td>
  <td><?php echo $rows['7'];?></td>
  <td><?php echo $rows['8'];?></td>
  <td><?php echo $rows['9'];?></td>
  <td><?php echo $rows['10'];?></td>
  <td><?php echo $rows['11'];?></td>
  <td><?php echo $rows['12'];?></td>
  <td><?php echo $rows['13'];?></td>
  <td><?php echo $rows['14'];?></td>
  <td><?php echo $rows['15'];?></td>
  <td><?php echo $rows['16'];?></td>
  <td><?php echo $rows['17'];?></td>
  <td><?php echo $rows['18'];?></td>
  <td><?php echo $rows['19'];?></td>
  <td><?php echo $rows['20'];?></td>
  <td><?php echo $rows['21'];?></td>
  <td><?php echo $rows['22'];?></td>
  <td><?php echo $rows['23'];?></td>
  <td><?php echo $rows['24'];?></td>
   <td><?php echo $rows['25'];?></td>
   <td><?php echo $rows['26'];?></td>
   <td><?php echo $rows['27'];?></td>
   <td><?php echo $rows['28'];?></td>
   <td><?php echo $rows['29'];?></td>
   <td><?php echo $rows['30'];?></td>
   <td><?php echo $rows['31'];?></td> 
    
    </tr>
    <?php
  }
?>
</tbody>
</thead>
</table>
</div>

    </body>
    
</html>
