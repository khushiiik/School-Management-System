<?php
session_start();
if(!isset($_SESSION['currentuser']))
{
  echo"<script>window.location.href='login.php';</script>";
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <link rel="stylesheet" href="dash.css?v<?php echo time(); ?>"/>
    <link rel="stylesheet" href="leave.css?v<?php echo time(); ?>"/>
    <link
      href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
      rel="stylesheet"
      />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
    <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
  
  </head>
  <body>

  <?php
include 'connection.php';

$sql = " SELECT * FROM stdinfo ORDER BY standard DESC";
$result = mysqli_query($conn,$sql);

?>
<?php
include 'connection.php';
// error_reporting(0);
$sql1="SELECT * FROM notice ORDER BY time DESC
";
$noti=mysqli_query($conn,$sql1);
?>


    <!-- ----header---- -->
    
    <div class="sidenav">
    <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->
 
  
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            <!-- <div class="close" id="close-btn">
              <span class="material-icons-sharp">close</span>
            </div> -->
          </div>
    
          <div class="sidebar">
            <a href="princi.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="studentinfo.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
    
            <a href="adviewatt.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
     -->
            <a href="notice.php" class="active">
              <span class="material-icons-sharp">event_note </span>
              <h3>Notice</h3>
            </a>
            <a href="leave_manage.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
      <!-- ------------------------------end of sidebar---------------------- -->
 <!-- --------------------------end of aside------------------------------------------------------------- -->

 <div class="main">
      <h1>Dash<span style="color: #097997;">board</span></h1>
        

        <div class="insights">
          <div class="students">
            
            <span class="material-icons-sharp">diversity_3</span>
            <div class="middle">
              <div class="left">
                <h2>Total Students</h2>
                              
<?php
$ret=mysqli_query($conn,"select uid from stdinfo");
$liststd=mysqli_num_rows($ret);
?>
                <h1 class="d-block display-4 text-dark mb-5" style="color: #097997;"><?php echo $liststd;?></h1>
  
              </div>
             
              </div>
             
            </div>

          <!-- ----------------------end of student----------------------------------- -->

          <div class="teacher">
            <div class="box">
          <div> <span class="material-icons-sharp">group </span></div>
          <div>  <h2>Total Teachers</h2></div>
          

            <?php
$ret=mysqli_query($conn,"select num from tchrinfo");
$listtchr=mysqli_num_rows($ret);
?>
<div>   <h1 class="d-block display-4 text-dark mb-5" style="color: #097997;"><?php echo $listtchr;?></h1></div>


            </div>
            
            </div>
            
          </div>
          <div class="stutable">  
        <h2>Not<span style="color: #097997;">ice</span></h2>
            <table>
            <tbody>
                
                <?php
               while($rows=$noti->fetch_assoc())
                {
                ?>
                <tr>
                  <td>
<h2><?php echo $rows['title'];?></h2>
  <p><?php echo $rows['detail'];?></p>
  <!-- <span class="material-symbols-sharp" name="delete" data-original-title="Delete" value="delete">
delete_sweep
</span>  -->

<h5 class="time-right" style="  margin-top: 1px;"><?php echo $rows['date'];?></h5>
<div class="container" style="display: flex; height: 42px;">
        <div style="width: 100%;">

<a href="edit_notice.php?sr=<?php echo $rows['sr_no']; ?>&tit=<?php echo $rows['title'];?>&det=<?php echo $rows['detail'];?>&dt=<?php echo $rows['date'];?>" class="mr-25" data-toggle="tooltip" data-original-title="Edit"> <i class="material-symbols-sharp">app_registration</i></a>
</div>
<div style="flex-grow: 1; margin-right: 5%;">


<a href="princi.php?delete=<?php echo $rows['title'];?>" data-toggle="tooltip" name="delete" data-original-title="Delete" onclick="return confirm('Do you really want to delete?');"> <i class="material-symbols-sharp">delete_sweep</i></a>
</div>
</div>

  <?php
if(isset($_GET['delete'])){
  $ntcdlt=$_GET['delete'];
  $sqldlt = "DELETE FROM notice WHERE title='$ntcdlt'";
  
  $rdlt = mysqli_query($conn, $sqldlt);
    
  // header("Refresh:0");
}

?>

                <?php
              }
          ?> 
          </td>
          </tr>
              </tbody>
            </table>
            <!-- <a href="#">Show All</a> -->
          </div>   
            </div>
<!-- ====================end of main================================= -->


<script src="./princi.js"></script>

  </body>
</html>
