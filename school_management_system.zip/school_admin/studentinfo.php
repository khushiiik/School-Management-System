<?php
session_start();
if(!isset($_SESSION['currentuser']))
{
  echo"<script>window.location.href='login.php';</script>";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="studentsform.css?v<?php echo time(); ?>">
    <link rel="stylesheet" href="leave.css?v<?php echo time(); ?>"> 

      <title>Student Form</title>

    <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
    rel="stylesheet"
    />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
  <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 





</head>
<body>

   
<div class="sidenav">
    <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->
 
  
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            <!-- <div class="close" id="close-btn">
              <span class="material-icons-sharp">close</span>
            </div> -->
          </div>
    
          <div class="sidebar">
            <a href="princi.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="studentinfo.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
    
            <a href="adviewatt.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
     -->
            <a href="notice.php" class="active">
              <span class="material-icons-sharp">event_note </span>
              <h3>Notice</h3>
            </a>
            <a href="leave_manage.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>         <!-- ------------------------------end of sidebar---------------------- -->

        <!-- ==========================main==================== -->
        
        <div class="main">
        <h1  style="margin-top: 20px;" >Student <span style="color: #097997;"> Form</span><a href="sdata.php" class="hstr" 
   >
   <span class="material-symbols-sharp">
demography
</span>
            <h3 class="hstr">Data</h3>
          </a></h1>
                <form action="studentinfo.php" method="POST">
                    <div class="row">
                  <div class="col-25">
                    <label for="grno">GR no.</label>
                    <input type="text" id="number" name="UID" pattern="[0-9]{4}" placeholder="0000" required>
            
            
                  </div>
                        <div class="col-25">
                            <label for="first-name">First Name</label>
                            <input type="text" id="first-name" name="FName" style="text-transform:capitalize" required>
                        </div>
                        <div class="col-25">
                            <label for="last-name">Last Name</label>
                            <input type="text" id="last-name" name="LName" style="text-transform:capitalize" required>
                        </div>
                        
                    </div>
                <div class="row">
                  <div class="col-25">
                            <label for="father-name">Father Name</label>
                            <input type="text" id="father-name" name="Father" style="text-transform:capitalize" required>
                        </div>
                        <div class="col-25">
                            <label for="mother-name">Mother Name</label>
                            <input type="text" id="mother-name" name="Mother" style="text-transform:capitalize" required>
                        </div>
                </div>
                
                <div class="row">
                  <div class="col-25">
                            <label for="birthdate">Birthdate</label>
                            <input type="date" id="DOB" name="DOB" onchange="calculateAge()" required>
                        </div>
                        <div class="col-25">
                            <label for="age">Age</label>
                            <input type="text" id="Age" name="Age" pattern="[0-9]{2}" placeholder="00" readonly required>
                        </div>
                </div>
                    <div class="row">
                        <div class="col-25">
                            <label for="gender">Gender</label>
                            <select id="gender" name="Gender" required>
                                <option value="">Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-25">
                            <label for="admission-date">Admission Date</label>
                    <input type="date" id="admission-date" name="Admission_date" required>
                        </div>
                  <div class="col-25">
                    <label for="bloodgrp">Blood Group</label>
                    <select id="bloodgrp" name="BloodG" required>
                      <option value="">Select</option>
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB</option>
                      </select>
                  </div>
                </div>
                
                <div class="row">
               
                  <div class="col-25">
                            <label for="caste">Caste</label>
                            <select id="caste" name="Caste" required>
                                <option value="">Select</option>
                                <option value="General">General</option>
                                <option value="OBC">OBC</option>
                                <option value="SC">SC</option>
                                <option value="ST">ST</option>
                                
                            </select>
                        </div>
                </div>
                <div class="row">
                    <div class="col-25">
                      <label for="Phone">Phone no.</label>
              <input type="tel" id="Phone" name="Phone" placeholder="Enter your phone number" pattern="[0-9]{10}" required>
                      </div>
                      <div class="col-25">
                    <label for="standard">Class</label>
                    <select id="standard" name="standard" required>
                      <option value="">Select</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7">7</option>
                      <option value="8">8</option>
              
                    </select>
                  </div>
                  </div>
                  <div class="row">
                  <div class="col-25">
                    <label for="email">Email:</label>
                      <input type="email" id="email" name="Email" placeholder="Enter your email address" required>
                      
                  </div>
                  <div class="col-25 addrs" >
                    <label for="address">Address:</label>
                    <textarea id="address" name="Address" placeholder="Enter your address" required></textarea>
                  </div>
                  </div>
                  <div class="row">
                    <div class="col-50">
                      <input type="submit" value="Submit" name="submit" onClick="window.location.reload()">
              
                    </div>
                  </div>
                </div>
              </form>

              <script>
function calculateAge() {
    var DOB = new Date(document.getElementById('DOB').value);
    var today = new Date();
    var Age = today.getFullYear() - DOB.getFullYear();
    var m = today.getMonth() - DOB.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < DOB.getDate())) {
        Age--;
    }
    document.getElementById('Age').value = Age;
}
</script>


              <?php
        include 'connection.php';
        // error_reporting(0);

        if(isset($_POST['submit']))
        {
            $uid=$_POST['UID'];
            // if(!is_numeric($uid < 0)){
            //   $error_message = "Please enter an valid Gr no.";
            //   }
            $fnm=$_POST['FName'];
            $lnm=$_POST['LName'];
            $fthr=$_POST['Father'];
            $mthr=$_POST['Mother'];
            $caste=$_POST['Caste'];
            $add=$_POST['Address'];
            $ph=$_POST['Phone'];
            // if(!is_numeric($ph < 0)){
            //   $error_message = "Please enter a valid Phone no.";
            //   }
            $email=$_POST['Email'];
            $std=$_POST['standard'];
            $dob=$_POST['DOB'];
            $today=date('Y-m-d');
            if($dob>$today){
              echo "<script>alert('Invalid date');</script>";
            }

            $age=$_POST['Age'];
            // if(!is_numeric($age < 0 || $age > 20)){
            // $error_message = "Please enter an age between 0 and 20.";
            // }
            $gndr=$_POST['Gender'];
            $ad_dt=$_POST['Admission_date'];
            if($ad_dt<$dob){
              echo "<script>alert('enter valid date');</script>";
            }

            $Bl_g=$_POST['BloodG'];
            
            
            $sql = "INSERT INTO stdinfo(`UID`,`FName`,`LName`,`DOB`,`Age`,`Gender`,`Admission_date`,`BloodG`,`Father`,`Mother`,`Caste`,`Address`,`Phone`,`Email`,`standard`) VALUES ($uid,'$fnm','$lnm','$dob',$age,'$gndr','$ad_dt','$Bl_g','$fthr','$mthr','$caste','$add',$ph,'$email','$std');";
            $result = mysqli_query($conn,$sql);
            if($result)
            {
                echo "success";
            }
            else{
                echo "failed";
            }
          }
          ?>

                </body>
</html>