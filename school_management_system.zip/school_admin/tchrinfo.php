<?php
session_start();
if(!isset($_SESSION['currentuser']))
{
  echo"<script>window.location.href='login.php';</script>";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Form</title>
    <link rel="stylesheet" href="tchrcss.css?v<?php echo time(); ?>">
    <link rel="stylesheet" href="leave.css?v<?php echo time(); ?>"> 


    <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
    rel="stylesheet"
    />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />

<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
  <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
</head>
<body>
<?php
include 'connection.php';
// error_reporting(0);

$sql = " SELECT * FROM tchrinfo ORDER BY num ASC";
$result = mysqli_query($conn,$sql);
?>


<div class="sidenav">
    <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->
 
  
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            <!-- <div class="close" id="close-btn">
              <span class="material-icons-sharp">close</span>
            </div> -->
          </div>
    
          <div class="sidebar">
            <a href="princi.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="studentinfo.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
    
            <a href="adviewatt.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
     -->
            <a href="notice.php" class="active">
              <span class="material-icons-sharp">event_note </span>
              <h3>Notice</h3>
            </a>
            <a href="leave_manage.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>      <!-- ------------------------------end of sidebar---------------------- -->

        <!-- ==========================main==================== -->
        
        <div class="main">
        <h1  style="margin-top: 20px;" >Teacher <span style="color: #097997;"> Form</span><a href="dataT.php" class="hstr" 
   >
   <span class="material-symbols-sharp">
demography
</span>
            <h3 class="hstr">Data</h3>
          </a></h1>
                <form action="tchrinfo.php" method="POST" autocomplete="off">
                    <div class="row">
                  <div class="col-25">
                    <label for="num">No</label>
                    <input type="text" id="num" name="num" pattern="[0-9]{2}" placeholder="00"  required>
            
            
                  </div>
                        <div class="col-25">
                            <label for="first-name">Name</label>
                            <input type="text" id="first-name" name="Name" style="text-transform:capitalize" required>
                        </div>
                        
                        
                    </div>
                <!-- <div class="row">
                  <div class="col-25">
                            <label for="father-name">Father Name</label>
                            <input type="text" id="father-name" name="father-name" required>
                        </div>
                        <div class="col-25">
                            <label for="mother-name">Mother Name</label>
                            <input type="text" id="mother-name" name="mother-name" required>
                        </div>
                </div> -->
                
                <div class="row">
                  <div class="col-25">
                    <label for="admission-date">Joining Date</label>
            <input type="date" id="Joining-Date" name="JoiningD" required>
                </div>
                  <div class="col-25">
                    <label for="Qualification">Qualification</label>
                    <input type="text" id="Qualification" name="Qualification" required>
                </div>
                
                        <div class="col-25">
                          <label for="WorkEp">Work Experience</label>
                          <input type="text" id="WorkEp" name="WorkEp" placeholder="Total year in no:00" pattern="[0-9]{2}" required>
                      </div>
                </div>
                    <div class="row">
                        <div class="col-25">
                            <label for="gender">Gender</label>
                            <select id="gender" name="Gender" required>
                                <option value="">Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-25">
                          <label for="birthdate">Birthdate</label>
                          <input type="date" id="birthdate" name="DOB" required>
                      </div>
                      
                  <div class="col-25">
                    <label for="bloodgrp">Blood Group</label>
                    <select id="bloodgrp" name="BloodG" required>
                        <option value="">Select</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        </select>
                  </div>
                </div>
                
                <div class="row">
                  <div class="col-25">
                          
                  <div class="col-25">
                            <label for="caste">Caste</label>
                            <select id="caste" name="Caste" required>
                                <option value="">Select</option>
                                <option value="General">General</option>
                                <option value="OBC">OBC</option>
                                <option value="SC">SC</option>
                                <option value="ST">ST</option>
                            </select>
                        </div>
                </div>
                <div class="row">
                    <div class="col-25">
                      <label for="cast">Phone no.</label>
              <input type="tel" id="phone" name="Phone"  pattern="[0-9]{10}" required>
                      </div>
                      <div class="col-25">
                        <label for="email">Email:</label>
                          <input type="email" id="email" name="Email" required>
                          
                      </div>
                  </div>
                  <div class="row">
                  <div class="col-25">
                    <label for="address">Address:</label>
                    <textarea  id="address" name="Address" required></textarea>
                </div>
                  </div>

                <div class="row">
                    <div class="col-50">
                    <input type="submit" value="Submit" name="submit" onclick="togglePopup()" style="width:1100px">
                    </div>
                  </div>
                </div>
              
              </form>

              <?php
        include 'connection.php';
        if(isset($_POST['submit']))
        {
            $num=$_POST['num'];
            $nm=$_POST['Name'];
            $dob=$_POST['DOB'];
            $qlf=$_POST['Qualification'];
            $gndr=$_POST['Gender'];
            $jn_dt=$_POST['JoiningD'];
            $workex=$_POST['WorkEp'];
            $Bl_g=$_POST['BloodG'];
            $caste=$_POST['Caste'];
            $ph=$_POST['Phone'];
            $email=$_POST['Email'];
            $add=$_POST['Address'];
            

            
            $sql = "INSERT INTO tchrinfo(`num`,`Name`,`DOB`,`Qualification`,`Gender`,`JoiningD`,`WorkEp`,`BloodG`,`Caste`,`Phone`,`Email`,`Address`) VALUES($num,'$nm','$dob','$qlf','$gndr','$jn_dt', $workex,'$Bl_g','$caste','$ph','$email','$add');";
            $result = mysqli_query($conn,$sql);
           
            // $sql = "INSERT INTO tchrinfo(`num`,`Name`,`DOB`,`Qualification`,`Gender`,`JoiningD`,`WorkEp`,`BloodG``,`Caste`,`Phone`,`Email`,`Address`) VALUES($num,'$nm','$dob','$qlf','$gndr','$jn_dt', $workex,'$Bl_g','$caste','$ph','$email','$add');";

            // $result = mysqli_query($conn,$sql);
            // if($result){
            //   echo "success";
            // }
            // else{
            //   echo "failed";
            // }
        }
        ?>


    </body>
</html>