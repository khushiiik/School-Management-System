<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History</title>
    <link rel="stylesheet" href="leave.css"/>
    <link rel="stylesheet" href="history.css"/>
    <link
    href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
    rel="stylesheet"
    />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
  <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
</head>
<body>

    <div class="sidenav">
        <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
            <!-- <div class="close" id="close-btn">
              <span class="material-icons-sharp">close</span>
            </div> -->
          </div>
    
          <div class="sidebar">
            <a href="tadmin.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="studentinfo.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <!-- <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a> -->
    
            <a href="tadattendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="fees.php" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a> -->
<!--     
            <a href="notice.php" class="active">
              <span class="material-icons-sharp">event_note </span>
              <h3>Notice</h3>
            </a> -->
            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
<!-- ======================================end of sidebar=========================================== -->
<div class="main">
    
    <div class="stutable">  
        
    <?php
        include 'connection.php';
        
$s=$_SESSION['id'];
        $sq="SELECT * FROM leavetbl WHERE `standard`=$s";
        $res=mysqli_query($conn, $sq);
        ?>

        <h1>His<span style="color: #097997;">tory</span><a href="leave.php" class="hstr">
            <span class="material-symbols-sharp">
                forward_to_inbox
                </span>
            <h3 class="hstr">Leave</h3>
          </a></h1>
            <table>
                
            <tbody>

            <?php
               while($rows=$res->fetch_assoc())
                {
                ?>

    <tr>                                                                                  
        <td>
          <h2><?php echo $rows['leave_type']; ?></h2> 

  <p><?php echo $rows['detail']; ?></p>
  <!-- <a data-toggle="tooltip" name="delete" data-original-title="Delete" onclick="return confirm('Do you really want to delete?');" href="history.php?delete=<?php echo $rows['sr_no'];?>"> <i class="material-symbols-sharp" style="cursor:pointer; font-size:28px; margin-right:20px;" >delete_sweep  </i>  -->
  <!-- <i class="material-symbols-sharp"  name="confirm" style="font-size:27px;">  thumb_up
</i> <i class="material-symbols-sharp"  name="reject" style="font-size:27px;">  thumb_down
</i> --></a>
<label><?php echo $rows['lv_st']; ?></label>

 <div class="time-right" style="margin-top: 0;">
<h5><i style="margin-right:10px; color:grey;"><?php echo $rows['fr_dt']; ?> </i> <i style="color:grey;">    <?php echo $rows['to_dt']; ?>
</i></h5></div>
          </td>
         <?php }
          ?>
            </tbody>
          </table>
          <!-- <a href="#">Show All</a> -->
        </div>  
</div>

<?php


if(isset($_GET['delete'])){
  @$sr=$_GET['sr_no'];
  // echo $sr;
  $dlt=$_GET['delete'];
  $sqldlt = "DELETE FROM `leavetbl` WHERE sr_no='$dlt'";
  
  $rdlt = mysqli_query($conn, $sqldlt);
}

?>

</body>
</html>