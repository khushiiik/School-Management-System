<?php
// session_start();
// if(!isset($_SESSION['currentuser']))
// {
//   echo"<script>window.location.href='login.php';</script>";
// }

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Teacher Admin</title>
    
  
    <link rel="stylesheet" href="tadmin.css?v<?php echo time(); ?>"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
    
    <link
      href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
      rel="stylesheet"
      />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
    <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
  
  </head>
  <body>



<?php
include 'connection.php';
session_start();
// error_reporting(0);
$sql1="SELECT * FROM notice ORDER BY time DESC";
$noti=mysqli_query($conn,$sql1);
?>

    <!-- ----header---- -->
    
    <div class="sidenav">
    <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->

  
              <h2>AD<span class="danger">MIN</span></h2>
            </div>

          </div>
    
          <div class="sidebar">
            
            <a href="tadmin.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="tadsdata.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>
    
            <a href="tadattendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
    -->
            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
      <!-- ------------------------------end of sidebar---------------------- -->
 <!-- --------------------------end of aside------------------------------------------------------------- -->
<div class="topnav">
  <a href="tadmin.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
            </a>
    
            <a href="tadsdata.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
            </a>
    
            <!-- <a href="tchrinfo.php" class="active">
              <span class="material-icons-sharp">group </span>
              <h3>Teachers</h3>
            </a>
     -->
            <a href="attendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
            </a>
    
            <!-- <a href="fees.php" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a> -->

            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
            </a>
</div>
<!-- =======================responsive sidebar================== -->

 <div class="main">
      <h1>Dash<span style="color: #097997;">board</span></h1>
        

        <div class="insights">
          <div class="students">
            
            <span class="material-icons-sharp">diversity_3</span>
            <div class="middle">
              <div class="left">
                <h2>Total Students</h2>

                <?php
  error_reporting(0);


$s=$_SESSION['id'];

  // if($std==`1`)
    $sql = " SELECT * FROM `stdinfo` WHERE `standard`=$s;";
  $result = mysqli_query($conn,$sql);
  $total= mysqli_num_rows($result);


?>
 <?php
//  $sq="SELECT `UID` FROM `stdinfo` WHERE `standard`=$s;";
//  $ret=mysqli_query($conn,$sq);
//  $liststd= mysqli_num_rows($ret);

 ?>     

               <h1 class="d-block display-4 text-dark mb-5" style="color: #097997;"><?php echo $total;?></h1>
              </div>
            
              </div>
             
            </div>

          <!-- ----------------------end of student----------------------------------- -->

          <div class="teacher">
            <div class="box">
          <div> <span class="material-icons-sharp">groups</span></div>
          <div>  <h2>Total Boys</h2></div>
          
          <?php
$b="SELECT UID FROM stdinfo WHERE `standard`=$s AND `Gender`='Male'";
$ret=mysqli_query($conn,$b);
$lb=mysqli_num_rows($ret);
?>

<div>   <h1 class="d-block display-4 text-dark mb-5" style="color: #097997;"><?php echo $lb;?></h1></div>

            </div>
            
          

            </div>
            <div class="teacher">
              <div class="box">
              <div> <span class="material-icons-sharp">groups_2</span></div>
            <div>  <h2>Total Girls</h2></div>
            <?php
$g="SELECT UID FROM stdinfo WHERE `standard`=$s AND `Gender`='Female'";
$ret=mysqli_query($conn,$g);
$lgirl=mysqli_num_rows($ret);
?>
  
<div>   <h1 class="d-block display-4 text-dark mb-5" style="color: #097997;"><?php echo $lgirl;?></h1></div>
  
  
              </div>
              
            
  
              </div>
          </div>
          <div class="stutable">  
        <h2>Not<span style="color: #097997;">ice</span></h2>
            <table style="  box-shadow:none;">
            <tbody>
            <?php
               while($rows=$noti->fetch_assoc())
                {
                ?>
                <tr>
                  <td>
                  <h2><?php echo $rows['title'];?></h2>
  <p><?php echo $rows['detail'];?></p>


  <h5 class="time-right" style="  margin-top: 1px;"><?php echo $rows['date'];?></h5>

  <?php
              }
          ?> 
          </td>
          </tr>
              </tbody>
            <!-- <a href="#">Show All</a> -->
          </div>   
            </div>
<!-- ====================end of main================================= -->


<script src="./princi.js"></script>

  </body>
</html>
