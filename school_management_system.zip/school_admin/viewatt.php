<?php
session_start();
$s=$_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Attendance</title>
  <link rel="stylesheet" href="attendence.css?v<?php echo time(); ?>">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
    
    <link
      href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp"
      rel="stylesheet"
      />
<!-- Google Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link
href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
rel="stylesheet"
/>
    <link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
rel="stylesheet"
/>
<!-- ------------------date----------------------- -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.1/jquery.js"></script>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
    <link rel="stylesheet" type="text/css" media="screen" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/base/jquery-ui.css">
    <script type="text/javascript">
       $(function() {
            $('.date-picker').datepicker( {
            changeMonth: true,
            changeYear: true,
            showButtonPanel: true,
            dateFormat: 'MM yy',
            onClose: function(dateText, inst) { 
                $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
            }
            });
        });
    </script>
     <style>
    .ui-datepicker-calendar {
        display: none;
    }
    </style>
    <!-- -------------------------------end---------------------------- -->
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.1.0/mdb.min.js"
></script> 
  
  </head>
  <body>

  <?php
include 'connection.php';

$sql = " SELECT * FROM stdinfo";
$result = mysqli_query($conn,$sql);

?>

    <!-- ----header---- -->
    
    <div class="sidenav">
    <div class="top">
            <div class="logo">
              <!-- <span style="height:50px; width: 40px;"><img src="schoollogo.jpg" alt="logo"></span> -->

  
              <h2>AD<span class="danger">MIN</span></h2>
            </div>
          
          </div>
    
          <div class="sidebar">
            <a href="tadmin.php" class="active">
              <span class="material-icons-sharp">dashboard </span>
              <h3>Dashboard</h3>
            </a>
    
            <a href="tadsdata.php" class="active">
              <span class="material-icons-sharp">diversity_3</span>
              <h3>Student</h3>
            </a>

            <a href="tadattendance.php" class="active">
              <span class="material-icons-sharp">history_edu</span>
              <h3>Attendance</h3>
            </a>
    
            <!-- <a href="#" class="active">
              <span class="material-icons-sharp">currency_rupee</span>
              <h3>Fees</h3>
            </a>
    -->
            <a href="leave.php" class="active">
            <span class="material-symbols-sharp">
    mark_email_read
    </span><h3>Leave</h3>
            </a>
            <a href="logout.php" class="active">
              <span class="material-icons-sharp">logout </span>
              <h3>Logout</h3>
            </a>
          </div>
      </div>
      <!-- ------------------------------end of sidebar---------------------- -->
 
</div>
<div class="main">


<div class="dte">
    <input style="color:darkbalck; background-color:white; width:100px; height:30px; border-radius: 10px; margin-top: 20px;" name="startDate" id="startDate" class="date-picker" placeholder=" Select Date" />
    
    <select required name="userType" class="form-control mb-3" style="color:gray; background-color:white; width:100px; height:30px; border-radius: 10px; margin-top: 20px; margin-left: 8px;
          "
          >
                          <option value="" style="display: none;" style="margin-right:10px;">  Select Class</option>
                          <option value="Administrator" style="color:black; ">1</option>
                          <option value="ClassTeacher" style="color:black;">2</option>
                          <option value="ClassTeacher" style="color:black;">3</option>
                          <option value="ClassTeacher" style="color:black;">4</option>
                          <option value="ClassTeacher" style="color:black;">5</option>
                          <option value="ClassTeacher" style="color:black;">6</option>
                          <option value="ClassTeacher" style="color:black;">7</option>
                          <option value="ClassTeacher" style="color:black;">8</option>


                        </select>
                 <button style="margin-left: 8px; background-color:#097997; color:
                 white; border-radius:20px; height
                 :30px; width:55px;">done</button>
    </div>
        <?php
            // error_reporting(0);
            include 'connection.php';
            
            $sql="SELECT * FROM `stdatt1`";
$result = mysqli_query($conn,$sql);

?>

            <div>
                <form action="tadviewatt.php" method="POST">
                <div class="stable"> 
                <!-- <h1 style="margin-top: 20px;" >Teacher <span style="color: #097997;"> Form</span><a href="tchrinfo.php" class="hstr" 
   >
   <span class="material-symbols-sharp">
description
</span>
            <h3 class="hstr">Form</h3>
          </a></h1> -->
                <div style="overflow-x:auto;text-align:left;">

<table style="width: 120%; margin-left:0; box-shadow: none;">
              <thead>
                <tbody>
                <th>UID</th>
                    <th>Standard</th>
                    <th>Name</th>
                    <th>1</th>
                    <th>2</th>
                    <th>3</th>
                    <th>4</th>
                    <th>5</th>
                    <th>6</th>
                    <th>7</th>
                    <th>8</th>
                    <th>9</th>
                    <th>10</th>
                    <th>11</th>
                    <th>12</th>
                    <th>13</th>
                    <th>14</th>
                    <th>15</th>
                    <th>16</th>
                    <th>17</th>
                    <th>18</th>
                    <th>19</th>
                    <th>20</th>
                    <th>21</th>
                    <th>22</th>
                    <th>23</th>
                    <th>24</th>
                    <th>25</th>
                    <th>26</th>
                    <th>27</th>
                    <th>28</th>
                    <th>29</th>
                    <th>30</th>
                    <th>31</th>
                   

                <?php   
              while($rows=$result->fetch_assoc())

              // $res=mysqli_query($conn, "SELECT COUNT(`1`) FROM `stdatt1`");
              // $data=mysqli_fetch_assoc($res);
              // echo $data['Total'];
                {
                 
                ?>
                <tr>
                   
                <td><?php echo $rows['UID'];?></td>
              <td><?php echo $rows['Standard'];?></td>
              <td><?php echo $rows['FName'];?></td>
              <td><?php echo $rows['1'];?></td>
              <td><?php echo $rows['2'];?></td>
              <td><?php echo $rows['3'];?></td>
              <td><?php echo $rows['4'];?></td>
              <td><?php echo $rows['5'];?></td>
              <td><?php echo $rows['6'];?></td>
              <td><?php echo $rows['7'];?></td>
              <td><?php echo $rows['8'];?></td>
              <td><?php echo $rows['9'];?></td>
              <td><?php echo $rows['10'];?></td>
              <td><?php echo $rows['11'];?></td>
              <td><?php echo $rows['12'];?></td>
              <td><?php echo $rows['13'];?></td>
              <td><?php echo $rows['14'];?></td>
              <td><?php echo $rows['15'];?></td>
              <td><?php echo $rows['16'];?></td>
              <td><?php echo $rows['17'];?></td>
              <td><?php echo $rows['18'];?></td>
              <td><?php echo $rows['19'];?></td>
              <td><?php echo $rows['20'];?></td>
              <td><?php echo $rows['21'];?></td>
              <td><?php echo $rows['22'];?></td>
              <td><?php echo $rows['23'];?></td>
              <td><?php echo $rows['24'];?></td>
               <td><?php echo $rows['25'];?></td>
               <td><?php echo $rows['26'];?></td>
               <td><?php echo $rows['27'];?></td>
               <td><?php echo $rows['28'];?></td>
               <td><?php echo $rows['29'];?></td>
               <td><?php echo $rows['30'];?></td>
               <td><?php echo $rows['31'];?></td> 
                
                </tr>
                <?php
              }
          ?>
            </tbody>
            </thead>
            </table>
            </div>
        </form>
</div>
        </body>
</html>